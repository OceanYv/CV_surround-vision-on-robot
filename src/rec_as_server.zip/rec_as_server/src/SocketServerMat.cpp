#include "SocketMatTransmissionServer.h"
#include <time.h>
 
int main()
{
	clock_t last_time;
	int init_flag = 0;
	SocketMatTransmissionServer socketMat;
	if (socketMat.socketConnect(6666) < 0)
		return 0;
	
	cv::namedWindow("picture_combine_receive",0);
	cv::Mat image;
	while (1){
		//接收图像
		if(socketMat.receive(image) > 0){
			cv::imshow("picture_combine_receive",image);
			cv::waitKey(25);
			last_time = clock();
			init_flag = 1;
		}
		else{
			std::cout<<"通过socket获取图像失败！"<<std::endl;
		}

		//判断是否等待时间过长
		if(init_flag == 1 && ((clock() - last_time)/CLOCKS_PER_SEC > 5.0)){
			std::cout<<"图像间隔超过5s，尝试重新建立..."<<std::endl;
			socketMat.socketDisconnect();
			cv::waitKey(1000);
			if (socketMat.socketConnect(6666) < 0)
				return 0;
			init_flag =0;
		}
	}
 
	socketMat.socketDisconnect();
	return 0;
}
